import java.util.HashMap;
import java.util.Iterator;

import es.upm.aedlib.indexedlist.ArrayIndexedList;
import es.upm.aedlib.indexedlist.IndexedList;

public class Analizador_lexico {
	//Objeto fichero que nos permite leer un fichero.
	private FicheroInput codeFile;

	//Objeto fichero que nos permite escribir en un fichero.
	private FicheroOutput tokensFile;
	
	//Objeto fichero que nos permite escribir la tabla de simbolos.
	private FicheroOutput tSFile;

	//El map donde vamos a introducir los identificadores, con su numero en la TS. 
	private HashMap<String, Integer> tablaDeSimbolos;	

	//Iremos metiendo los identificadores en esta lista para facilitar el print. 
	private IndexedList<String> listaSimbolos;

	//El siguiente caracter y su codigo ascii.
	private char nextChar;
	private int charASCII;

	//lexicoico para las cadenas que vallamos leyendo.
	private String lexico;
	private int longit;

	//Numero para los numeros que vallamos leyendo.
	private int num;

	//El estado y la accion actual del automata finito determinista
	private int estado;
	private String accion;

	//Contador de la posicion de la tabla de simbolos.
	private int pos_TS;
	
	//Enumerador de lineas del texto
	private int nLinea;
	
	private boolean eof;

	private final Pair[][] AFD = {{new Pair(0, "A"), new Pair(1, "B"), new Pair(3, "C"), new Pair(2, "A"), new Pair(4, "A"), new Pair(5, "A"), new Pair(6, "A"), new Pair(15, "S"), new Pair(-1, "6"), new Pair(0,"A")},
			{new Pair(8, "I"), new Pair(1, "B"), new Pair(1, "B"), new Pair(8, "I"), new Pair(8, "I"), new Pair(8, "I"), new Pair(8, "I"), new Pair(8, "I"), new Pair(8, "I"), new Pair(8, "I")},
			{new Pair(2, "B"), new Pair(2, "B"), new Pair(2, "B"), new Pair(9, "G9"), new Pair(2, "B"), new Pair(2, "B"), new Pair(2, "B"), new Pair(2, "B"), new Pair(2, "B"), new Pair(-1, "4")},
			{new Pair(8, "G3"), new Pair(-1, "1"), new Pair(3, "C"), new Pair(11, "G3"), new Pair(11, "G3"), new Pair(11, "G3"), new Pair(11, "G3"), new Pair(11, "G3"), new Pair(11, "G3"), new Pair(11, "G3")},
			{new Pair(-1, "2"), new Pair(-1, "2"), new Pair(-1, "2"), new Pair(-1, "2"), new Pair(12, "G7"), new Pair(-1, "2"), new Pair(-1, "2"), new Pair(-1, "2"), new Pair(-1, "2"), new Pair(-1, "2")},
			{new Pair(-1, "3"), new Pair(-1, "3"), new Pair(-1, "3"), new Pair(-1, "3"), new Pair(-1, "3"), new Pair(13, "G10"), new Pair(-1, "3"), new Pair(-1, "3"), new Pair(-1, "3"), new Pair(-1, "3")},
			{new Pair(-1, "4"), new Pair(-1, "4"), new Pair(-1, "4"), new Pair(-1, "4"), new Pair(-1, "4"), new Pair(-1, "4"), new Pair(7, "A"), new Pair(-1, "4"), new Pair(-1, "4"), new Pair(-1, "4")},
			{new Pair(7, "A"), new Pair(7, "A"), new Pair(7, "A"), new Pair(7, "A"), new Pair(7, "A"), new Pair(7, "A"), new Pair(7, "A"), new Pair(7, "A"), new Pair(14, "A"), new Pair(14, "A")}};

	public Analizador_lexico(String direccionInput, String direccionOutput, String direccionTS, HashMap<String, Integer> TS) {
		tablaDeSimbolos = TS;
		listaSimbolos = new ArrayIndexedList<String>();
		codeFile = new FicheroInput(direccionInput);
		tokensFile = new FicheroOutput(direccionOutput);
		tSFile = new FicheroOutput(direccionTS);
		pos_TS = 1;
		eof = false;
		nLinea = 1;
	}
	
	

	public String nextToken() {
		Pair par;
		String token = ""; 
		lexico = "";
		num = 0;
		estado = 0;
		accion = "";
		longit = 0;

		while(estado>=0 && estado<8 && charASCII != -1 ){
			charASCII = codeFile.nextASCIIChar();
			nextChar = (char) charASCII;

			if (charASCII == 32 || charASCII == 9) {
				par = AFD[estado][0];
			} else if (charASCII >= 48 && charASCII <= 57) {
				par = AFD[estado][2];
				//System.out.println("ASCII " + charASCII + ": Digit");
			} else if ((charASCII >= 65 && charASCII <= 90) || charASCII == 95) {
				par = AFD[estado][1];
			} else if (charASCII >= 97 && charASCII <= 122) {
				par = AFD[estado][1];
			} else if(charASCII == 34){
				par = AFD[estado][3];
				//System.out.println("ASCII " + charASCII + ": Special Character");
			} else if(charASCII == 43){
				par = AFD[estado][4];
				//System.out.println("ASCII " + charASCII + ": Special Character");
			} else if(charASCII == 38){
				par = AFD[estado][5];
				//System.out.println("ASCII " + charASCII + ": Special Character");
			} else if(charASCII == 47){
				par = AFD[estado][6];
				//System.out.println("ASCII " + charASCII + ": Special Character");
			} else if(charASCII == 45 || charASCII == 44 || charASCII == 61 || charASCII == 60 || charASCII == 59 || charASCII == 40 || charASCII == 41 || charASCII == 123 || charASCII == 125){
				par = AFD[estado][7];
			} else if(charASCII == 10 || charASCII == 13){
				par = AFD[estado][9];
				//System.out.println("ASCII " + charASCII + ": Special Character");
			}
			else if(charASCII == -1){
				par = new Pair(8, "EOF");
				eof = true;
			}
			else {
				System.out.println("This caracter -> "+charASCII+"-"+nextChar+" is considered another caracter\n");
				par = AFD[estado][8];
			}

			estado = par.getKey();
			accion = par.getValue();
			//System.out.println("This caracter -> "+charASCII+"-"+nextChar+"\n");
			//System.out.println("El siguiente posicion es: "+estado+" Con la accion: "+accion+"\n\n");

			if(estado == -1){
				switch (accion){
					case "1": token = "Error_Numero en la linea "+nLinea;
					break;
					case "2": token = "Error_Incremento en la linea "+nLinea;
					break;
					case "3": token = "Error_AND en la linea "+nLinea;
					break;
					case "4": token = "Error_String en la linea "+nLinea;
					break;
					case "5": token = "Otros_Errores en la linea "+nLinea;
					break;
					case "6": token = "Letra desconocida en la linea " +nLinea+" : "+nextChar;

				}
				codeFile.leer();
			}
			else if(!eof){
				if (accion.compareTo("A")==0) {
					codeFile.leer();
					if(charASCII == 10){
						nLinea++;
					}
				} else if (accion.compareTo("B")==0) {
					lexico += nextChar;
					longit++;
					codeFile.leer();
				} else if (accion.compareTo("C")==0) {
					num = num * 10 + (charASCII - 48);
					codeFile.leer(); // (0,9) - 0
				} else if (accion.compareTo("I")==0) {
					if (lexico.compareTo("boolean")==0) {
						token = "<011, > //es un boolean\n";
					} else if (lexico.compareTo("else")==0) {
						token = "<106, > //es un else\n";
					} else if (lexico.compareTo("function")==0) {
						token = "<101, > //es un function\n";
					} else if (lexico.compareTo("get")==0) {
						token = "<103, > //es un get\n";
					} else if (lexico.compareTo("if")==0) {
						token = "<105, > //es un if\n";
					} else if (lexico.compareTo("int")==0) {
						token = "<010, > //es un int\n";
					} else if (lexico.compareTo("put")==0) {
						token = "<104, > //es un put\n";
					} else if (lexico.compareTo("let")==0) {
						token = "<102, > //es un let\n";
					} else if (lexico.compareTo("return")==0) {
						token = "<107, > //es un return\n";
					} else if (lexico.compareTo("string")==0) {
						token = "<012, > //es un string\n";
					} else if (lexico.compareTo("void")==0) {
						token = "<013, > //es un void\n";
					} else {
						if(tablaDeSimbolos.containsKey(lexico)){  //Si esta en la tabla de simbolos
							token = "<200, " + tablaDeSimbolos.get(lexico) + "> //es un identificador con posicion en la tabla de simbolos:" +tablaDeSimbolos.get(lexico)+ "\n"; //Doy el valor del lexicoico
						}
						else{
							if(tablaDeSimbolos.isEmpty()){ 
								tSFile.escribir("CONTENIDOS DE LA TABLA # 100 :\r");
							}
							tablaDeSimbolos.put(lexico, pos_TS);
							listaSimbolos.add(listaSimbolos.size(), lexico);
							token = "<200, " + pos_TS + "> //es un identificador con posicion en la tabla de simbolos:" +tablaDeSimbolos.get(lexico)+ "\n";
							pos_TS++;
						}
					}
				} else if (accion == "G3") {
					if (num < 32767) {
						token = "<402, " + num + "> //es una constante con valor " + num + "\n";
					}
					else {
						token = "Error numero fuera de rango. Linea de error "+nLinea+" numero en cuestion: "+num; 
					}
				} else if (accion == "S") {
					if (nextChar == '-') {
						token = "<301, > //es un -\n";
					} else if (nextChar == '<') {
						token = "<302, > //es un <\n";
					} else if (nextChar == '=') {
						token = "<201, > //es un =\n";
					} else if (nextChar == ',') {
						token = "<202, > //es un ,\n";
					} else if (nextChar == ';') {
						token = "<203, > //es un ;\n";
					} else if (nextChar == '(') {
						token = "<204, > //es un (\n";
					} else if (nextChar == ')') {
						token = "<205, > //es un )\n";
					} else if (nextChar == '{') {
						token = "<206, > //es un {\n";
					} else if (nextChar == '}') {
						token = "<207, > //es un }\n";
					}
					codeFile.leer();
				} else if (accion == "G7") {
					token = "<304, > // es un ++\n";
					codeFile.leer();

				} else if (accion == "G9") {
					if (longit <= 64) {
						token = "<401, " + lexico + "> //es una cadena\n";
						codeFile.leer();
					}
					else {
						token = "Error string demasiado largo. Linea de error "+nLinea+" el string en cuestion: "+lexico; 
					}
				} else if (accion == "G10") {
					token = "<303, > //es un &&\n";
					codeFile.leer();
				}
			}

		}
		if(eof) {
			token = "<666, EOF>";
		}

		tokensFile.escribir(token);
		
		return token;
	}

	public void printTS(){
		Iterator<String> it = listaSimbolos.iterator();
		while(it.hasNext()){
			tSFile.escribir("* LEXEMA : '"+it.next()+"'\n");
		}
	}
	
	public void closeFiles() {
		tokensFile.cerrarFichero();
		codeFile.cerrarFichero();
		tSFile.cerrarFichero();
	}
	
	public boolean endFile() {
		return eof;
	}
}
