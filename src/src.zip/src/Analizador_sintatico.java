import java.awt.print.Printable;
import java.util.HashMap;
import java.util.Map;

import es.upm.aedlib.fifo.FIFO;
import es.upm.aedlib.lifo.LIFO;
import es.upm.aedlib.lifo.LIFOArray;

public class Analizador_sintatico {

	private Analizador_lexico alexico; 

	private final String[][] ACCION = new String[99][26];
	private LIFO<String> pila;
	private Pair[] n_consecuente = {new Pair(1, "A"), new Pair(2, "P"), new Pair(2, "P"), new Pair(0, "P"),
			new Pair(4, "F"), new Pair(4, "F1"), new Pair(3, "F2"), new Pair(5, "B"),
			new Pair(4, "C"), new Pair(1, "C"), new Pair(4, "D"), new Pair(0, "D"),
			new Pair(4, "B"), new Pair(1, "B"), new Pair(4, "S"), new Pair(3, "S"),
			new Pair(3, "S"), new Pair(3, "S"), new Pair(3, "S"), new Pair(5, "S"),
			new Pair(3, "E"), new Pair(1, "E"), new Pair(3, "Z"), new Pair(1, "Z"),
			new Pair(3, "G"), new Pair(1, "G"), new Pair(1, "H"), new Pair(3, "H"), 
			new Pair(1, "H"), new Pair(1, "H"), new Pair(4, "H"), new Pair(2, "I"),
			new Pair(0, "I"), new Pair(1, "J"), new Pair(1, "J"), new Pair(2, "K"),
			new Pair(3, "L"), new Pair(1, "L"), new Pair(4, "M"), new Pair(0, "M"),
			new Pair(2, "N"), new Pair(0, "N") ,new Pair(3, "O"), new Pair(0, "O"),
			new Pair(1, "Q"), new Pair(0, "Q"), new Pair(1, "T"), new Pair(1, "T"),
			new Pair(1, "T"), new Pair(2, "X"), new Pair(0, "X")};//Aqui tiene el numero de consecuentes de cada regla con el antecedente.
	private final String[][] GOTO = new String[99][23];
	private Map<String, Integer> tablaDeSimbolos;
	private HashMap<String, Integer> mp;

	public Analizador_sintatico(Analizador_lexico AL, Map<String, Integer> TS, String accionFile, String GOTOFile) {
		alexico = AL;
		tablaDeSimbolos = TS;
		pila = new LIFOArray<>();
		crearAccion(accionFile);
		crearGOTO(GOTOFile);
		mp = new HashMap<>();
		functAux();
	}
	
	private void functAux() {
		mp.put("P", 0);
		mp.put("F", 1);
		mp.put("F1", 2);
		mp.put("F2", 3);
		mp.put("B", 4);
		mp.put("C", 5);
		mp.put("D", 6);
		mp.put("S", 7);
		mp.put("E", 8);
		mp.put("G", 9);
		mp.put("H", 10);
		mp.put("I", 11);
		mp.put("J", 12);
		mp.put("K", 13);
		mp.put("L", 14);
		mp.put("M", 15);
		mp.put("N", 16);
		mp.put("O", 17);
		mp.put("Q", 18);
		mp.put("T", 19);
		mp.put("X", 20);
		mp.put("Z", 21);
	}


	public void run() {



		String sigToken = alexico.nextToken();
		int estado = 0;
		int nColumna;
		String accion = "";
		String next = "";
		int cod = 0;
		int reglaReducc = 0;

		pila.push("0");
		
		
		
		while(cod != 666) {
			
			
			cod = Integer.parseInt(sigToken.substring(sigToken.indexOf("<")+1, sigToken.indexOf(",")));
			switch (cod){
			case 11: {
				next = "boolean";
				nColumna = 10; //Buscar en que columna est� el token boolean, que es empezando desde el 0, el 10.
				break;
			}
			case 106: {
				next = "else";
				nColumna = 12; 
				break;
			}
			case 101: {
				next = "function";
				nColumna = 14; 
				break;
			}
			case 103: {
				next = "get";
				nColumna = 15; //Buscar en que columna est� el token boolean, que es empezando desde el 0, el 10.
				break;
			}
			case 105: {
				next = "if";
				nColumna = 17; //Buscar en que columna est� el token boolean, que es empezando desde el 0, el 10.
				break;
			}
			case 10: {
				next = "int";
				nColumna = 18; //Buscar en que columna est� el token boolean, que es empezando desde el 0, el 10.
				break;
			}
			case 102: {
				next = "let";
				nColumna = 19; //Buscar en que columna est� el token boolean, que es empezando desde el 0, el 10.
				break;
			}
			case 104: {
				next = "put";
				nColumna = 20; //Buscar en que columna est� el token boolean, que es empezando desde el 0, el 10.
				break;
			}
			case 107: {
				next = "return";
				nColumna = 21; //Buscar en que columna est� el token boolean, que es empezando desde el 0, el 10.
				break;
			}
			case 12: {
				next = "string";
				nColumna = 22; //Buscar en que columna est� el token boolean, que es empezando desde el 0, el 10.
				break;
			}
			case 13: {
				next = "void";
				nColumna = 23; //Buscar en que columna est� el token boolean, que es empezando desde el 0, el 10.
				break;
			}
			case 304: {
				next = "++";
				nColumna = 4; //Buscar en que columna est� el token boolean, que es empezando desde el 0, el 10.
				break;
			}
			case 402: {
				next = "entero";
				nColumna = 13; //Buscar en que columna est� el token boolean, que es empezando desde el 0, el 10.
				break;
			}
			case 401: {
				next = "cadena";
				nColumna = 11; //Buscar en que columna est� el token boolean, que es empezando desde el 0, el 10.
				break;
			}
			case 201: {
				next = "=";
				nColumna = 9; //Buscar en que columna est� el token boolean, que es empezando desde el 0, el 10.
				break;
			}
			case 202: {
				next = ",";
				nColumna = 5; //Buscar en que columna est� el token boolean, que es empezando desde el 0, el 10.
				break;
			}
			case 203: {
				next = ";";
				nColumna = 7; //Buscar en que columna est� el token boolean, que es empezando desde el 0, el 10.
				break;
			}
			case 204: {
				next = "(";
				nColumna = 2; //Buscar en que columna est� el token boolean, que es empezando desde el 0, el 10.
				break;
			}
			case 205: {
				next = ")";
				nColumna = 3; //Buscar en que columna est� el token boolean, que es empezando desde el 0, el 10.
				break;
			}
			case 206: {
				next = "{";
				nColumna = 24; //Buscar en que columna est� el token boolean, que es empezando desde el 0, el 10.
				break;
			}
			case 207: {
				next = "}";
				nColumna = 25; //Buscar en que columna est� el token boolean, que es empezando desde el 0, el 10.
				break;
			}
			case 301: {
				next = "-";
				nColumna = 6; //Buscar en que columna est� el token boolean, que es empezando desde el 0, el 10.
				break;
			}
			case 303: {
				next = "&&";
				nColumna = 1; //Buscar en que columna est� el token boolean, que es empezando desde el 0, el 10.
				break;
			}
			case 302: {
				next = "<";
				nColumna = 8; //Buscar en que columna est� el token boolean, que es empezando desde el 0, el 10.
				break;
			}
			case 666: {
				next = "EOF";
				nColumna = 0; //Buscar en que columna est� el token boolean, que es empezando desde el 0, el 10.
				break;
			}
			//Poner aqui todos los dem�s terminales segun nuestra gramatica de tokens.
			case 200: {
				next = "id";
				nColumna = 16;
				break;
			}
			default:
				throw new IllegalArgumentException("Unexpected value: " + cod);
			}
			accion = ACCION[estado][nColumna];

			if(!accion.isEmpty() && accion.charAt(0) == 'd') {
				pila.push(next);
				pila.push(accion.substring(1));
				
				estado = Integer.parseInt(accion.substring(1));
				sigToken = alexico.nextToken();
			}
			else if(!accion.isEmpty() && accion.charAt(0) == 'r'){

				reglaReducc = Integer.parseInt(accion.substring(1));
				
				System.out.print(reglaReducc+"\t");
				
				int numDeConsecuentes = n_consecuente[reglaReducc].getKey();
				String antecedente = n_consecuente[reglaReducc].getValue();
				
				//Quitar todos los consecuentes por 2 de la pila.
				for(int i = 1 ; i<=2*numDeConsecuentes; i++) {
					pila.pop();
				}
				int aux = Integer.parseInt(pila.top());
				//Aniadir el antecedente
				pila.push(antecedente);
				
				estado = Integer.parseInt(GOTO[aux][mp.get(pila.top())]);  
				pila.push(Integer.toString(estado));

			}
			else if(!accion.isEmpty() && accion.compareTo("aceptar") == 0) {
				return ;
			}
			else {
				System.out.println("Error");
			}

		}

	}


	private void crearAccion(String direccionInput) {
		FicheroInput codeFile = new FicheroInput(direccionInput);

		int asciiChar = codeFile.nextASCIIChar();
		int i=0, j=0;
		String aux="";
		boolean asignar = true;

		while(asciiChar != -1) {
			asignar = false;
			aux="";
			System.out.println(asciiChar);
			switch (asciiChar){
			case 9: {
				ACCION[i][j] = "";
				asignar = true;
				break;
			}
			case 10: break;
			case 13: {
				ACCION[i][j] = "";
				asignar = true;
				break;
			}
			case 97: {
				aux+= (char) (asciiChar);
				codeFile.leer();
				while(codeFile.nextASCIIChar() >=97 && codeFile.nextASCIIChar() <= 122) {
					aux+= (char)(codeFile.nextASCIIChar());
					codeFile.leer();
				}
				//sin terminar, para r24 por ejemplo
				ACCION[i][j] = aux;
				asignar = true;
				break;
			}
			case 100:
			case 114: {
				aux+= (char) (asciiChar);
				codeFile.leer();
				while(codeFile.nextASCIIChar() >=48 && codeFile.nextASCIIChar() <= 57) {
					aux+= (char)(codeFile.nextASCIIChar());
					codeFile.leer();
				}
				//sin terminar, para r24 por ejemplo
				ACCION[i][j] = aux;
				asignar = true;
				break;
			}
			default:
				throw new IllegalArgumentException("Unexpected value: " + asciiChar);
			}

			//System.out.println(asciiChar + " Que es el carater \""+(char)asciiChar+"\" "+" \n");
			//Resultados: 13 y 10 son saltos de linea, mientras que 9 es blank space, 114 es r, 100 es d
			if(asciiChar != 100 || asciiChar != 114) {
				codeFile.leer();
			}
			asciiChar = codeFile.nextASCIIChar();
			if(asignar) {
				//Avanzar a la siguiente casilla
				if(j<25) {
					j++;
				}else {
					i++;
					j=0;
				}
			}

		}codeFile.cerrarFichero();

	}
	private void crearGOTO(String direccionInput) {
		FicheroInput codeFile = new FicheroInput(direccionInput);

		int asciiChar = codeFile.nextASCIIChar();
		int i=0, j=0;
		String aux = "";
		boolean asignar = true;
		
		while(asciiChar != -1) {
			
			asignar = false;
			aux = "";
			if(codeFile.nextASCIIChar() >=48 && codeFile.nextASCIIChar() <= 57) {
				aux += (char)(asciiChar);
				codeFile.leer();
				while(codeFile.nextASCIIChar() >=48 && codeFile.nextASCIIChar() <= 57) {
					aux += (char)(codeFile.nextASCIIChar());
					codeFile.leer();
				}
				//sin terminar, para r24 por ejemplo
				GOTO[i][j] = aux;
				asignar = true;
			}
			else {
				switch (asciiChar){
				case 9: {
					GOTO[i][j] = "";
					asignar = true;
					break;
				}
				case 10: {
					GOTO[i][j] = "";
				asignar = true;
				break;
				}
				case 13: {
					GOTO[i][j] = "";
					asignar = true;
					break;
				}
				default:
					throw new IllegalArgumentException("Unexpected value: " + asciiChar);
				}
			}
			
			
			/*System.out.println(asciiChar + " Que es el carater \""+(char)asciiChar+"\" "+" \n");
			codeFile.leer();
			asciiChar = codeFile.nextASCIIChar();
			*/
			//Resultados: 13 y 10 son saltos de linea, mientras que 9 es blank space, 114 es r, 100 es d
			
			//if(!(asciiChar >=48 && asciiChar <=57)) {
				codeFile.leer();
			//}
			asciiChar = codeFile.nextASCIIChar();
			if(asignar) {
				//Avanzar a la siguiente casilla
				if(j<22) {
					j++;
				}else {
					i++;
					j=0;
				}
			}
		}codeFile.cerrarFichero();

	}

	public void imprimir(String file) {
		FicheroOutput ficheroOutput = new FicheroOutput(file);
		
		for(int i=0 ; i<99 ; i++) {
			for(int j=0 ; j<26 ; j++) {
				ficheroOutput.escribir( ACCION[i][j]+"\t"); 
			}
			ficheroOutput.escribir("\n");
			
		}
		
		
		for(int i=0 ; i<99 ; i++) {
			for(int j=0 ; j<23 ; j++) {
				ficheroOutput.escribir(GOTO[i][j]+"\t");
			}
			ficheroOutput.escribir("\n");
		}
		System.out.println("El elemento indicado es: "+GOTO[58][9]);
		ficheroOutput.cerrarFichero();
	}

}
