import java.util.HashMap;

public class Main {
	
	public static void main(String[] args){
		
		String codigoFuente = "FicheroFuente.txt";
		String ficheroToken = "FicheroToken.txt";
		String ficheroTS = "FicheroTS.txt";
		
		HashMap<String, Integer> tablaDeSimbolos = new HashMap<>();
		
		
		
	    Analizador_lexico aLexico = new Analizador_lexico(codigoFuente, ficheroToken, ficheroTS, tablaDeSimbolos);
	    Analizador_sintatico aSintatico = new Analizador_sintatico(aLexico, tablaDeSimbolos, "acciones.txt", "GOTO.txt");
	    /*
	    aSintatico.crearAccion("acciones.txt");
	    aSintatico.crearGOTO("GOTO.txt");

	    aSintatico.imprimir("auxiliar.txt");
	    */
	    aSintatico.run();
	    
	    /*
	    while(!aLexico.endFile()) {
	    	System.out.println(aLexico.nextToken()+"\n");
	    }*/
	    
	    
		//aLexico.printTS();
		//aLexico.closeFiles();

	}
}
