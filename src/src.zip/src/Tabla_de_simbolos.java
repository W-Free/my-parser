import java.util.HashMap;
import java.util.Map;

public class Tabla_de_simbolos {
	private Map<String, Integer> tablaDeSimbolos;
	
	public Tabla_de_simbolos() {
		tablaDeSimbolos = new HashMap<>();
	}
	
	public boolean containsKey(String key) {
		return tablaDeSimbolos.containsKey(key);
	}
	
	public void add(String lex, int pos) {
		tablaDeSimbolos.put(lex, pos);
	}
	
	public boolean isEmpty() {
		return tablaDeSimbolos.isEmpty();
	}
	
	
}
